package com.livreo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green=Color(0xFF16A34A)

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){
  super.onCreate(savedInstanceState)
  setContent{LivreoApp()}
 }
}

@Composable
fun LivreoApp(){
 var page by remember{mutableStateOf("home")}
 MaterialTheme(colorScheme=lightColorScheme(primary=Green)){
  Surface(Modifier.fillMaxSize()){
   when(page){
    "home"->Home({page="client"},{page="livreur"})
    "client"->Client({page="home"})
    "livreur"->Livreur({page="home"})
   }
  }
 }
}

@Composable
fun Home(client:()->Unit, livreur:()->Unit){
 Column(Modifier.fillMaxSize().padding(24.dp),
  horizontalAlignment=Alignment.CenterHorizontally,
  verticalArrangement=Arrangement.Center){
  Text("LIVREO",fontSize=44.sp,fontWeight=FontWeight.Bold,color=Green)
  Text("Livraison simple, rapide et sécurisée")
  Spacer(Modifier.height(35.dp))
  Button(client,Modifier.fillMaxWidth()){Text("Je suis Client")}
  Spacer(Modifier.height(12.dp))
  OutlinedButton(livreur,Modifier.fillMaxWidth()){Text("Je suis Livreur")}
 }
}

@Composable
fun Client(back:()->Unit){
 var depart by remember{mutableStateOf("")}
 var dest by remember{mutableStateOf("")}
 var sent by remember{mutableStateOf(false)}
 Column(Modifier.fillMaxSize().padding(20.dp)){
  Text("Livreo • Client",fontSize=27.sp,fontWeight=FontWeight.Bold,color=Green)
  Spacer(Modifier.height(18.dp))
  OutlinedTextField(depart,{depart=it},Modifier.fillMaxWidth(),label={Text("Adresse de récupération")})
  Spacer(Modifier.height(10.dp))
  OutlinedTextField(dest,{dest=it},Modifier.fillMaxWidth(),label={Text("Destination")})
  Spacer(Modifier.height(10.dp))
  OutlinedTextField("",{},Modifier.fillMaxWidth(),label={Text("Description du colis")})
  Spacer(Modifier.height(18.dp))
  Button({sent=true},enabled=depart.isNotBlank()&&dest.isNotBlank(),Modifier.fillMaxWidth()){
   Text("Demander une livraison")
  }
  if(sent){
   Spacer(Modifier.height(18.dp))
   Card(Modifier.fillMaxWidth()){
    Column(Modifier.padding(16.dp)){
     Text("Demande envoyée ✅",fontWeight=FontWeight.Bold)
     Text("Livreo propose votre livraison aux livreurs disponibles à proximité.")
    }
   }
  }
  Spacer(Modifier.weight(1f))
  TextButton(back){Text("Retour")}
 }
}

@Composable
fun Livreur(back:()->Unit){
 var accepted by remember{mutableStateOf(false)}
 Column(Modifier.fillMaxSize().padding(20.dp)){
  Text("Livreo • Livreur",fontSize=27.sp,fontWeight=FontWeight.Bold,color=Green)
  Spacer(Modifier.height(18.dp))
  Card(Modifier.fillMaxWidth()){
   Column(Modifier.padding(16.dp)){
    Text("Nouvelle proposition",fontWeight=FontWeight.Bold,fontSize=19.sp)
    Spacer(Modifier.height(8.dp))
    Text("📦 Anosibe → Analakely")
    Text("Distance estimée : 4,2 km")
    Spacer(Modifier.height(12.dp))
    if(!accepted){
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
      Button({accepted=true}){Text("Accepter")}
      OutlinedButton({}){Text("Refuser")}
     }
    }else{
     Text("Mission acceptée ✅",fontWeight=FontWeight.Bold,color=Green)
     Spacer(Modifier.height(8.dp))
     Button({}){Text("Marquer « En route »")}
    }
   }
  }
  Spacer(Modifier.weight(1f))
  TextButton(back){Text("Retour")}
 }
}
